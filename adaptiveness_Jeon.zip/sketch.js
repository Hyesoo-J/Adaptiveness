let temperature = 0;
let humidity = 0;
let arduinoColor;

let video;
let gridSize;

let mic;
let amp;


let bubbles = [];
let bubbleLimit = 5000;
let lastSoundDetected = 0;
let displayCameraPixels = true;


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


function setup() {
  createCanvas(1745, 975);
  frameRate(60);

  let fullscreenButton = createButton('Fullscreen');
  fullscreenButton.position(10, 10);
  fullscreenButton.mousePressed(toggleFullScreen);
  
  // Arduino serial port setup
  serial = new p5.SerialPort();
  serial.open('COM7');
  serial.onData(dataReceived);
  
  // Video setup
  video = createCapture(VIDEO);
  video.size(2120, 1160);
  video.hide();
 
  // Video pixel setup
  gridSize = int(map(mouseX, 0, width, 15, 50));
  arduinoColor = color(0);

  // Mic setup for the sound detection
  mic = new p5.AudioIn();
  mic.start();
  amp = new p5.Amplitude();
  amp.setInput(mic);
}


// Displaying full-screen mode
function toggleFullScreen() {
  let fs = fullscreen();
  fullscreen(!fs);
}

// Receiving data from the Arduino
function dataReceived() {
  let data = serial.readStringUntil('\r\n');
  if (data) {
    let values = data.split(',');

    humidity = float(values[0]);
    temperature = float(values[1]);
    let redValue = int(values[2]);
    let greenValue = int(values[3]);
    let blueValue = int(values[4]);

    arduinoColor = color(redValue, greenValue, blueValue);
  }
}


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


let bubblesVisible = false; // while camera pixels are beign displayed bubbles are not shown up

function draw() {
  clear();

  if (displayCameraPixels) {
    video.loadPixels();
    for (let y = 0; y < video.height; y += gridSize) {
      for (let x = 0; x < video.width; x += gridSize) {
        let index = (y * video.width + x) * 4;
        let r = video.pixels[index];
        let dia = map(r, 0, 255, gridSize, 2);

        fill(arduinoColor);
        noStroke();
        circle(x + gridSize / 2, y + gridSize / 2, dia);
      }
    }
  }

  let level = amp.getLevel();

    if (level > 0.005) {
    lastSoundDetected = millis();
    displayCameraPixels = false; // stop displaying camera pixels while sound is detected
    bubblesVisible = true; // set bubbles can be displayed
    
    let shapeType = '';
    let shapeSize = level * width * 2; // polygon shape will be changed follownig the level of the sound volume
    
    // following the each condition the polygons are differnciated
    if (level > 0.05) { 
      shapeType = 'ellipse';
    } else if (level > 0.020) {
      shapeType = 'nonagon';
    } else if (level > 0.015) {
      shapeType = 'heptagon';
    } else if (level > 0.010) {
      shapeType = 'pentagon';
    } else if (level > 0.005) {
      shapeType = 'triangle';
    }
      
    if (bubbles.length < bubbleLimit) {
      let newShape = new Bubble(random(width), random(height), shapeSize, getArduinoColor(temperature, humidity), shapeType);
      bubbles.push(newShape);
    }
    
    for (let i = 0; i < bubbles.length; i++) {
      let shape = bubbles[i];
      shape.run();
    }
  } else {
    if (millis() - lastSoundDetected > 2000) { // if there is no sound anymore for 3sec then it goes back the the camera pixel view
      lastSoundDetected = 0;
      displayCameraPixels = true; 
      bubblesVisible = false;
      bubbles = [];
    }
  }
  
  // keep displaying bubbles on the screen
  if (bubblesVisible) { 
    background(arduinoColor);
    for (let i = 0; i < bubbles.length; i++) {
      let bubble = bubbles[i];
      bubble.display();
    }
  }
}


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


class Bubble {
  constructor(x, y, size, color, shapeType) {
    this.position = createVector(x, y);
    this.velocity = p5.Vector.random2D().mult(2);
    this.size = size;
    this.color = color;
    this.shapeType = shapeType;
    this.angle = 0;
    this.rotationSpeed = random(-0.1, 0.1);
  }

  run() {
    this.update();
    this.borders();
    this.display();
  }

  update() {
    this.position.add(this.velocity); // update the polygon's loaction
    this.angle += this.rotationSpeed; // update the angle for rotation
  }

  borders() {
    if (this.position.x < 0 || this.position.x > width) {
      this.velocity.x *= -1;
    }
    if (this.position.y < 0 || this.position.y > height) {
      this.velocity.y *= -1;
    }
  }

  display() {
    noStroke();
    fill(this.color);

    push(); // save the current transformation state
    translate(this.position.x, this.position.y); // move the origin to the shape's position
    rotate(this.angle); // rotate the shape
    if (this.shapeType === 'ellipse') {
      ellipse(0, 0, this.size, this.size);
    } else if (this.shapeType === 'nonagon') {
      let numberOfSides = 9;
      let angle = TWO_PI / numberOfSides;
      beginShape();
      for (let i = 0; i < numberOfSides; i++) {
        let x = cos(i * angle) * this.size;
        let y = sin(i * angle) * this.size;
        vertex(x, y);
      }
      endShape(CLOSE);
    } else if (this.shapeType === 'heptagon') {
      let numberOfSides = 7;
      let angle = TWO_PI / numberOfSides;
      beginShape();
      for (let i = 0; i < numberOfSides; i++) {
        let x = cos(i * angle) * this.size;
        let y = sin(i * angle) * this.size;
        vertex(x, y);
      }
      endShape(CLOSE);
    } else if (this.shapeType === 'pentagon') {
      let numberOfSides = 5;
      let angle = TWO_PI / numberOfSides;
      beginShape();
      for (let i = 0; i < numberOfSides; i++) {
        let x = cos(i * angle + PI) * this.size;
        let y = sin(i * angle + PI) * this.size;
        vertex(x, y);
      }
      endShape(CLOSE);
    } else if (this.shapeType === 'triangle') {
      let numberOfSides = 3;
      let angle = TWO_PI / numberOfSides;
      beginShape();
      for (let i = 0; i < numberOfSides; i++) {
        let x = cos(i * angle + PI) * this.size;
        let y = sin(i * angle + PI) * this.size;
        vertex(x, y);
      }
      endShape(CLOSE);
    }
    pop(); // Restore the previous transformation state
  }
}

function getArduinoColor(temperature, humidity) {
  let arduinoColor;

  if (temperature >= 25.20) {
    arduinoColor = color(random(100, 255), random(0, 100), random(0, 100));
  } else {
    arduinoColor = color(random(0, 100), random(0, 100), random(100, 255));
  }

  if (humidity < 25) {
    arduinoColor.setAlpha(200);
  } else if (25 < humidity && humidity < 50) {
    arduinoColor.setAlpha(150);
  } else {
    arduinoColor.setAlpha(50);
  }

  return arduinoColor;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


// Part of capturing the image by pressing the mouse
function keyPressed() {
  if (keyCode === ENTER) {
    // Use the obtained access token after user authentication and authorization
    captureScreen();
  }
}

function captureScreen() {
  // Use html2canvas to capture the screen
  html2canvas(document.body).then(function (canvas) {
    // Convert the canvas to a data URL
    const dataURL = canvas.toDataURL("image/png");

    // Create an anchor element to download the image
    const a = document.createElement('a');
    a.href = dataURL;
    a.download = 'captured_image.png';
    a.click();
  });
}
